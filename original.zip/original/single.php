<?php
/**
 * The template to display single post
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

// Full post loading
$full_post_loading          = original_get_value_gp( 'action' ) == 'full_post_loading';

// Prev post loading
$prev_post_loading          = original_get_value_gp( 'action' ) == 'prev_post_loading';
$prev_post_loading_type     = original_get_theme_option( 'posts_navigation_scroll_which_block', 'article' );

// Position of the related posts
$original_related_position   = original_get_theme_option( 'related_position', 'below_content' );

// Type of the prev/next post navigation
$original_posts_navigation   = original_get_theme_option( 'posts_navigation' );
$original_prev_post          = false;
$original_prev_post_same_cat = (int)original_get_theme_option( 'posts_navigation_scroll_same_cat', 1 );

// Rewrite style of the single post if current post loading via AJAX and featured image and title is not in the content
if ( ( $full_post_loading 
		|| 
		( $prev_post_loading && 'article' == $prev_post_loading_type )
	) 
	&& 
	! in_array( original_get_theme_option( 'single_style' ), array( 'style-6' ) )
) {
	original_storage_set_array( 'options_meta', 'single_style', 'style-6' );
}

do_action( 'original_action_prev_post_loading', $prev_post_loading, $prev_post_loading_type );

get_header();

while ( have_posts() ) {

	the_post();

	// Type of the prev/next post navigation
	if ( 'scroll' == $original_posts_navigation ) {
		$original_prev_post = get_previous_post( $original_prev_post_same_cat );  // Get post from same category
		if ( ! $original_prev_post && $original_prev_post_same_cat ) {
			$original_prev_post = get_previous_post( false );                    // Get post from any category
		}
		if ( ! $original_prev_post ) {
			$original_posts_navigation = 'links';
		}
	}

	// Override some theme options to display featured image, title and post meta in the dynamic loaded posts
	if ( $full_post_loading || ( $prev_post_loading && $original_prev_post ) ) {
		original_sc_layouts_showed( 'featured', false );
		original_sc_layouts_showed( 'title', false );
		original_sc_layouts_showed( 'postmeta', false );
	}

	// If related posts should be inside the content
	if ( strpos( $original_related_position, 'inside' ) === 0 ) {
		ob_start();
	}

	// Display post's content
	get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/content', 'single-' . original_get_theme_option( 'single_style' ) ), 'single-' . original_get_theme_option( 'single_style' ) );

	// If related posts should be inside the content
	if ( strpos( $original_related_position, 'inside' ) === 0 ) {
		$original_content = ob_get_contents();
		ob_end_clean();

		ob_start();
		do_action( 'original_action_related_posts' );
		$original_related_content = ob_get_contents();
		ob_end_clean();

		if ( ! empty( $original_related_content ) ) {
			$original_related_position_inside = max( 0, min( 9, original_get_theme_option( 'related_position_inside' ) ) );
			if ( 0 == $original_related_position_inside ) {
				$original_related_position_inside = mt_rand( 1, 9 );
			}

			$original_p_number         = 0;
			$original_related_inserted = false;
			$original_in_block         = false;
			$original_content_start    = strpos( $original_content, '<div class="post_content' );
			$original_content_end      = strrpos( $original_content, '</div>' );

			for ( $i = max( 0, $original_content_start ); $i < min( strlen( $original_content ) - 3, $original_content_end ); $i++ ) {
				if ( $original_content[ $i ] != '<' ) {
					continue;
				}
				if ( $original_in_block ) {
					if ( strtolower( substr( $original_content, $i + 1, 12 ) ) == '/blockquote>' ) {
						$original_in_block = false;
						$i += 12;
					}
					continue;
				} else if ( strtolower( substr( $original_content, $i + 1, 10 ) ) == 'blockquote' && in_array( $original_content[ $i + 11 ], array( '>', ' ' ) ) ) {
					$original_in_block = true;
					$i += 11;
					continue;
				} else if ( 'p' == $original_content[ $i + 1 ] && in_array( $original_content[ $i + 2 ], array( '>', ' ' ) ) ) {
					$original_p_number++;
					if ( $original_related_position_inside == $original_p_number ) {
						$original_related_inserted = true;
						$original_content = ( $i > 0 ? substr( $original_content, 0, $i ) : '' )
											. $original_related_content
											. substr( $original_content, $i );
					}
				}
			}
			if ( ! $original_related_inserted ) {
				if ( $original_content_end > 0 ) {
					$original_content = substr( $original_content, 0, $original_content_end ) . $original_related_content . substr( $original_content, $original_content_end );
				} else {
					$original_content .= $original_related_content;
				}
			}
		}

		original_show_layout( $original_content );
	}

	// Comments
	do_action( 'original_action_before_comments' );
	comments_template();
	do_action( 'original_action_after_comments' );

	// Related posts
	if ( 'below_content' == $original_related_position
		&& ( 'scroll' != $original_posts_navigation || (int)original_get_theme_option( 'posts_navigation_scroll_hide_related', 0 ) == 0 )
		&& ( ! $full_post_loading || (int)original_get_theme_option( 'open_full_post_hide_related', 1 ) == 0 )
	) {
		do_action( 'original_action_related_posts' );
	}

	// Post navigation: type 'scroll'
	if ( 'scroll' == $original_posts_navigation && ! $full_post_loading ) {
		?>
		<div class="nav-links-single-scroll"
			data-post-id="<?php echo esc_attr( get_the_ID( $original_prev_post ) ); ?>"
			data-post-link="<?php echo esc_attr( get_permalink( $original_prev_post ) ); ?>"
			data-post-title="<?php the_title_attribute( array( 'post' => $original_prev_post ) ); ?>"
			data-cur-post-link="<?php echo esc_attr( get_permalink() ); ?>"
			data-cur-post-title="<?php the_title_attribute(); ?>"
			<?php do_action( 'original_action_nav_links_single_scroll_data', $original_prev_post ); ?>
		></div>
		<?php
	}
}

get_footer();
