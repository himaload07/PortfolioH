<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

							do_action( 'original_action_page_content_end_text' );
							
							// Widgets area below the content
							original_create_widgets_area( 'widgets_below_content' );
						
							do_action( 'original_action_page_content_end' );
							?>
						</div>
						<?php
						
						do_action( 'original_action_after_page_content' );

						// Show main sidebar
						get_sidebar();

						do_action( 'original_action_content_wrap_end' );
						?>
					</div>
					<?php

					do_action( 'original_action_after_content_wrap' );

					// Widgets area below the page and related posts below the page
					$original_body_style = original_get_theme_option( 'body_style' );
					$original_widgets_name = original_get_theme_option( 'widgets_below_page', 'hide' );
					$original_show_widgets = ! original_is_off( $original_widgets_name ) && is_active_sidebar( $original_widgets_name );
					$original_show_related = original_is_single() && original_get_theme_option( 'related_position', 'below_content' ) == 'below_page';
					if ( $original_show_widgets || $original_show_related ) {
						if ( 'fullscreen' != $original_body_style ) {
							?>
							<div class="content_wrap">
							<?php
						}
						// Show related posts before footer
						if ( $original_show_related ) {
							do_action( 'original_action_related_posts' );
						}

						// Widgets area below page content
						if ( $original_show_widgets ) {
							original_create_widgets_area( 'widgets_below_page' );
						}
						if ( 'fullscreen' != $original_body_style ) {
							?>
							</div>
							<?php
						}
					}
					do_action( 'original_action_page_content_wrap_end' );
					?>
			</div>
			<?php
			do_action( 'original_action_after_page_content_wrap' );

			// Don't display the footer elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ( ! original_is_singular( 'post' ) && ! original_is_singular( 'attachment' ) ) || ! in_array ( original_get_value_gp( 'action' ), array( 'full_post_loading', 'prev_post_loading' ) ) ) {
				
				// Skip link anchor to fast access to the footer from keyboard
				?>
				<span id="footer_skip_link_anchor" class="original_skip_link_anchor"></span>
				<?php

				do_action( 'original_action_before_footer' );

				// Footer
				$original_footer_type = original_get_theme_option( 'footer_type' );
				if ( 'custom' == $original_footer_type && ! original_is_layouts_available() ) {
					$original_footer_type = 'default';
				}
				get_template_part( apply_filters( 'original_filter_get_template_part', "templates/footer-" . sanitize_file_name( $original_footer_type ) ) );

				do_action( 'original_action_after_footer' );

			}
			?>

			<?php do_action( 'original_action_page_wrap_end' ); ?>

		</div>

		<?php do_action( 'original_action_after_page_wrap' ); ?>

	</div>

	<?php do_action( 'original_action_after_body' ); ?>

	<?php wp_footer(); ?>

</body>
</html>