<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: //codex.wordpress.org/Template_Hierarchy
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

$original_template = apply_filters( 'original_filter_get_template_part', original_blog_archive_get_template() );

if ( ! empty( $original_template ) && 'index' != $original_template ) {

	get_template_part( $original_template );

} else {

	original_storage_set( 'blog_archive', true );

	get_header();

	if ( have_posts() ) {

		// Query params
		$original_stickies   = is_home()
								|| ( in_array( original_get_theme_option( 'post_type' ), array( '', 'post' ) )
									&& (int) original_get_theme_option( 'parent_cat' ) == 0
									)
										? get_option( 'sticky_posts' )
										: false;
		$original_post_type  = original_get_theme_option( 'post_type' );
		$original_args       = array(
								'blog_style'     => original_get_theme_option( 'blog_style' ),
								'post_type'      => $original_post_type,
								'taxonomy'       => original_get_post_type_taxonomy( $original_post_type ),
								'parent_cat'     => original_get_theme_option( 'parent_cat' ),
								'posts_per_page' => original_get_theme_option( 'posts_per_page' ),
								'sticky'         => original_get_theme_option( 'sticky_style', 'inherit' ) == 'columns'
															&& is_array( $original_stickies )
															&& count( $original_stickies ) > 0
															&& get_query_var( 'paged' ) < 1
								);

		original_blog_archive_start();

		do_action( 'original_action_blog_archive_start' );

		if ( is_author() ) {
			do_action( 'original_action_before_page_author' );
			get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/author-page' ) );
			do_action( 'original_action_after_page_author' );
		}

		if ( original_get_theme_option( 'show_filters', 0 ) ) {
			do_action( 'original_action_before_page_filters' );
			original_show_filters( $original_args );
			do_action( 'original_action_after_page_filters' );
		} else {
			do_action( 'original_action_before_page_posts' );
			original_show_posts( array_merge( $original_args, array( 'cat' => $original_args['parent_cat'] ) ) );
			do_action( 'original_action_after_page_posts' );
		}

		do_action( 'original_action_blog_archive_end' );

		original_blog_archive_end();

	} else {

		if ( is_search() ) {
			get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/content', 'none-search' ), 'none-search' );
		} else {
			get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/content', 'none-archive' ), 'none-archive' );
		}
	}

	get_footer();
}
