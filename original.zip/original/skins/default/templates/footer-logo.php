<?php
/**
 * The template to display the site logo in the footer
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.10
 */

// Logo
if ( original_is_on( original_get_theme_option( 'logo_in_footer' ) ) ) {
	$original_logo_image = original_get_logo_image( 'footer' );
	$original_logo_text  = get_bloginfo( 'name' );
	if ( ! empty( $original_logo_image['logo'] ) || ! empty( $original_logo_text ) ) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if ( ! empty( $original_logo_image['logo'] ) ) {
					$original_attr = original_getimagesize( $original_logo_image['logo'] );
					echo '<a href="' . esc_url( home_url( '/' ) ) . '">'
							. '<img src="' . esc_url( $original_logo_image['logo'] ) . '"'
								. ( ! empty( $original_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $original_logo_image['logo_retina'] ) . ' 2x"' : '' )
								. ' class="logo_footer_image"'
								. ' alt="' . esc_attr__( 'Site logo', 'original' ) . '"'
								. ( ! empty( $original_attr[3] ) ? ' ' . wp_kses_data( $original_attr[3] ) : '' )
							. '>'
						. '</a>';
				} elseif ( ! empty( $original_logo_text ) ) {
					echo '<h1 class="logo_footer_text">'
							. '<a href="' . esc_url( home_url( '/' ) ) . '">'
								. esc_html( $original_logo_text )
							. '</a>'
						. '</h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
