<?php
/**
 * The template to display the background video in the header
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.14
 */
$original_header_video = original_get_header_video();
$original_embed_video  = '';
if ( ! empty( $original_header_video ) && ! original_is_from_uploads( $original_header_video ) ) {
	if ( original_is_youtube_url( $original_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $original_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php original_show_layout( original_get_embed_video( $original_header_video ) ); ?></div>
		<?php
	}
}
