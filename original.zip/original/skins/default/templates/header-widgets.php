<?php
/**
 * The template to display the widgets area in the header
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

// Header sidebar
$original_header_name    = original_get_theme_option( 'header_widgets' );
$original_header_present = ! original_is_off( $original_header_name ) && is_active_sidebar( $original_header_name );
if ( $original_header_present ) {
	original_storage_set( 'current_sidebar', 'header' );
	$original_header_wide = original_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $original_header_name ) ) {
		dynamic_sidebar( $original_header_name );
	}
	$original_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $original_widgets_output ) ) {
		$original_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $original_widgets_output );
		$original_need_columns   = strpos( $original_widgets_output, 'columns_wrap' ) === false;
		if ( $original_need_columns ) {
			$original_columns = max( 0, (int) original_get_theme_option( 'header_columns' ) );
			if ( 0 == $original_columns ) {
				$original_columns = min( 6, max( 1, original_tags_count( $original_widgets_output, 'aside' ) ) );
			}
			if ( $original_columns > 1 ) {
				$original_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $original_columns ) . ' widget', $original_widgets_output );
			} else {
				$original_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $original_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'original_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $original_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $original_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'original_action_before_sidebar', 'header' );
				original_show_layout( $original_widgets_output );
				do_action( 'original_action_after_sidebar', 'header' );
				if ( $original_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $original_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'original_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
