<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

$original_args = get_query_var( 'original_logo_args' );

// Site logo
$original_logo_type   = isset( $original_args['type'] ) ? $original_args['type'] : '';
$original_logo_image  = original_get_logo_image( $original_logo_type );
$original_logo_text   = original_is_on( original_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$original_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $original_logo_image['logo'] ) || ! empty( $original_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $original_logo_image['logo'] ) ) {
			if ( empty( $original_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric($original_logo_image['logo']) && (int) $original_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$original_attr = original_getimagesize( $original_logo_image['logo'] );
				echo '<img src="' . esc_url( $original_logo_image['logo'] ) . '"'
						. ( ! empty( $original_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $original_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $original_logo_text ) . '"'
						. ( ! empty( $original_attr[3] ) ? ' ' . wp_kses_data( $original_attr[3] ) : '' )
						. '>';
			}
		} else {
			original_show_layout( original_prepare_macros( $original_logo_text ), '<span class="logo_text">', '</span>' );
			original_show_layout( original_prepare_macros( $original_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
