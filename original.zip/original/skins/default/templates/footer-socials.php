<?php
/**
 * The template to display the socials in the footer
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.10
 */


// Socials
if ( original_is_on( original_get_theme_option( 'socials_in_footer' ) ) ) {
	$original_output = original_get_socials_links();
	if ( '' != $original_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php original_show_layout( $original_output ); ?>
			</div>
		</div>
		<?php
	}
}
