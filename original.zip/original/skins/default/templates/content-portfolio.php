<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

$original_template_args = get_query_var( 'original_template_args' );
if ( is_array( $original_template_args ) ) {
	$original_columns    = empty( $original_template_args['columns'] ) ? 2 : max( 1, $original_template_args['columns'] );
	$original_blog_style = array( $original_template_args['type'], $original_columns );
    $original_columns_class = original_get_column_class( 1, $original_columns, ! empty( $original_template_args['columns_tablet']) ? $original_template_args['columns_tablet'] : '', ! empty($original_template_args['columns_mobile']) ? $original_template_args['columns_mobile'] : '' );
} else {
	$original_template_args = array();
	$original_blog_style = explode( '_', original_get_theme_option( 'blog_style' ) );
	$original_columns    = empty( $original_blog_style[1] ) ? 2 : max( 1, $original_blog_style[1] );
    $original_columns_class = original_get_column_class( 1, $original_columns );
}

$original_post_format = get_post_format();
$original_post_format = empty( $original_post_format ) ? 'standard' : str_replace( 'post-format-', '', $original_post_format );

?><div class="
<?php
if ( ! empty( $original_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( original_is_blog_style_use_masonry( $original_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $original_columns ) : esc_attr( $original_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $original_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $original_columns )
		. ( 'portfolio' != $original_blog_style[0] ? ' ' . esc_attr( $original_blog_style[0] )  . '_' . esc_attr( $original_columns ) : '' )
	);
	original_add_blog_animation( $original_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	$original_hover   = ! empty( $original_template_args['hover'] ) && ! original_is_inherit( $original_template_args['hover'] )
								? $original_template_args['hover']
								: original_get_theme_option( 'image_hover' );

	if ( 'dots' == $original_hover ) {
		$original_post_link = empty( $original_template_args['no_links'] )
								? ( ! empty( $original_template_args['link'] )
									? $original_template_args['link']
									: get_permalink()
									)
								: '';
		$original_target    = ! empty( $original_post_link ) && original_is_external_url( $original_post_link ) && function_exists( 'original_external_links_target' )
								? original_external_links_target()
								: '';
	}
	
	// Meta parts
	$original_components = ! empty( $original_template_args['meta_parts'] )
							? ( is_array( $original_template_args['meta_parts'] )
								? $original_template_args['meta_parts']
								: explode( ',', $original_template_args['meta_parts'] )
								)
							: original_array_get_keys_by_value( original_get_theme_option( 'meta_parts' ) );

	// Featured image
	original_show_post_featured( apply_filters( 'original_filter_args_featured', 
        array(
			'hover'         => $original_hover,
			'no_links'      => ! empty( $original_template_args['no_links'] ),
			'thumb_size'    => ! empty( $original_template_args['thumb_size'] )
								? $original_template_args['thumb_size']
								: original_get_thumb_size(
									original_is_blog_style_use_masonry( $original_blog_style[0] )
										? (	strpos( original_get_theme_option( 'body_style' ), 'full' ) !== false || $original_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( original_get_theme_option( 'body_style' ), 'full' ) !== false || $original_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => original_is_blog_style_use_masonry( $original_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $original_components,
			'class'         => 'dots' == $original_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $original_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $original_post_link )
												? '<a href="' . esc_url( $original_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $original_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $original_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $original_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!