<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap
<?php
$original_copyright_scheme = original_get_theme_option( 'copyright_scheme' );
if ( ! empty( $original_copyright_scheme ) && ! original_is_inherit( $original_copyright_scheme  ) ) {
	echo ' scheme_' . esc_attr( $original_copyright_scheme );
}
?>
				">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
			<?php
				$original_copyright = original_get_theme_option( 'copyright' );
			if ( ! empty( $original_copyright ) ) {
				// Replace {{Y}} or {Y} with the current year
				$original_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $original_copyright );
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$original_copyright = original_prepare_macros( $original_copyright );
				// Display copyright
				echo wp_kses( nl2br( $original_copyright ), 'original_kses_content' );
			}
			?>
			</div>
		</div>
	</div>
</div>
