<?php
/**
 * The template to display default site header
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

$original_header_css   = '';
$original_header_image = get_header_image();
$original_header_video = original_get_header_video();
if ( ! empty( $original_header_image ) && original_trx_addons_featured_image_override( is_singular() || original_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$original_header_image = original_get_current_mode_image( $original_header_image );
}

?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $original_header_image ) || ! empty( $original_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $original_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $original_header_image ) {
		echo ' ' . esc_attr( original_add_inline_css_class( 'background-image: url(' . esc_url( $original_header_image ) . ');' ) );
	}
	if ( is_single() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	if ( original_is_on( original_get_theme_option( 'header_fullheight' ) ) ) {
		echo ' header_fullheight original-full-height';
	}
	$original_header_scheme = original_get_theme_option( 'header_scheme' );
	if ( ! empty( $original_header_scheme ) && ! original_is_inherit( $original_header_scheme  ) ) {
		echo ' scheme_' . esc_attr( $original_header_scheme );
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $original_header_video ) ) {
		get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/header-navi' ) );

	// Mobile header
	if ( original_is_on( original_get_theme_option( 'header_mobile_enabled' ) ) ) {
		get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/header-mobile' ) );
	}

	// Page title and breadcrumbs area
	if ( ! is_single() ) {
		get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/header-title' ) );
	}

	// Header widgets area
	get_template_part( apply_filters( 'original_filter_get_template_part', 'templates/header-widgets' ) );
	?>
</header>
