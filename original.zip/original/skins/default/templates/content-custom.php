<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.50
 */

$original_template_args = get_query_var( 'original_template_args' );
if ( is_array( $original_template_args ) ) {
	$original_columns    = empty( $original_template_args['columns'] ) ? 2 : max( 1, $original_template_args['columns'] );
	$original_blog_style = array( $original_template_args['type'], $original_columns );
} else {
	$original_template_args = array();
	$original_blog_style = explode( '_', original_get_theme_option( 'blog_style' ) );
	$original_columns    = empty( $original_blog_style[1] ) ? 2 : max( 1, $original_blog_style[1] );
}
$original_blog_id       = original_get_custom_blog_id( join( '_', $original_blog_style ) );
$original_blog_style[0] = str_replace( 'blog-custom-', '', $original_blog_style[0] );
$original_expanded      = ! original_sidebar_present() && original_get_theme_option( 'expand_content' ) == 'expand';
$original_components    = ! empty( $original_template_args['meta_parts'] )
							? ( is_array( $original_template_args['meta_parts'] )
								? join( ',', $original_template_args['meta_parts'] )
								: $original_template_args['meta_parts']
								)
							: original_array_get_keys_by_value( original_get_theme_option( 'meta_parts' ) );
$original_post_format   = get_post_format();
$original_post_format   = empty( $original_post_format ) ? 'standard' : str_replace( 'post-format-', '', $original_post_format );

$original_blog_meta     = original_get_custom_layout_meta( $original_blog_id );
$original_custom_style  = ! empty( $original_blog_meta['scripts_required'] ) ? $original_blog_meta['scripts_required'] : 'none';

if ( ! empty( $original_template_args['slider'] ) || $original_columns > 1 || ! original_is_off( $original_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $original_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( original_is_off( $original_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $original_custom_style ) ) . "-1_{$original_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $original_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $original_columns )
					. ' post_layout_' . esc_attr( $original_blog_style[0] )
					. ' post_layout_' . esc_attr( $original_blog_style[0] ) . '_' . esc_attr( $original_columns )
					. ( ! original_is_off( $original_custom_style )
						? ' post_layout_' . esc_attr( $original_custom_style )
							. ' post_layout_' . esc_attr( $original_custom_style ) . '_' . esc_attr( $original_columns )
						: ''
						)
		);
	original_add_blog_animation( $original_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'original_action_show_layout', $original_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $original_template_args['slider'] ) || $original_columns > 1 || ! original_is_off( $original_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
