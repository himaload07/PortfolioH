<?php
/**
 * The template to display Admin notices
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0.64
 */

$original_skins_url  = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$original_skins_args = get_query_var( 'original_skins_notice_args' );
?>
<div class="original_admin_notice original_skins_notice notice notice-info is-dismissible" data-notice="skins">
	<?php
	// Theme image
	$original_theme_img = original_get_file_url( 'screenshot.jpg' );
	if ( '' != $original_theme_img ) {
		?>
		<div class="original_notice_image"><img src="<?php echo esc_url( $original_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'original' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="original_notice_title">
		<?php esc_html_e( 'New skins are available', 'original' ); ?>
	</h3>
	<?php

	// Description
	$original_total      = $original_skins_args['update'];	// Store value to the separate variable to avoid warnings from ThemeCheck plugin!
	$original_skins_msg  = $original_total > 0
							// Translators: Add new skins number
							? '<strong>' . sprintf( _n( '%d new version', '%d new versions', $original_total, 'original' ), $original_total ) . '</strong>'
							: '';
	$original_total      = $original_skins_args['free'];
	$original_skins_msg .= $original_total > 0
							? ( ! empty( $original_skins_msg ) ? ' ' . esc_html__( 'and', 'original' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d free skin', '%d free skins', $original_total, 'original' ), $original_total ) . '</strong>'
							: '';
	$original_total      = $original_skins_args['pay'];
	$original_skins_msg .= $original_skins_args['pay'] > 0
							? ( ! empty( $original_skins_msg ) ? ' ' . esc_html__( 'and', 'original' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d paid skin', '%d paid skins', $original_total, 'original' ), $original_total ) . '</strong>'
							: '';
	?>
	<div class="original_notice_text">
		<p>
			<?php
			// Translators: Add new skins info
			echo wp_kses_data( sprintf( __( "We are pleased to announce that %s are available for your theme", 'original' ), $original_skins_msg ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="original_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $original_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			esc_html_e( 'Go to Skins manager', 'original' );
			?>
		</a>
		<?php
		// Dismiss notice for 7 days
		?>
		<a href="#" role="button" class="button button-secondary original_notice_button_dismiss" data-notice="skins"><i class="dashicons dashicons-no-alt"></i> 
			<?php
			esc_html_e( 'Dismiss', 'original' );
			?>
		</a>
		<?php
		// Hide notice forever
		?>
		<a href="#" role="button" class="button button-secondary original_notice_button_hide" data-notice="skins"><i class="dashicons dashicons-no-alt"></i> 
			<?php
			esc_html_e( 'Never show again', 'original' );
			?>
		</a>
	</div>
</div>
