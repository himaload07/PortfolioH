<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package ORIGINAL
 * @since ORIGINAL 1.0
 */

if ( original_sidebar_present() ) {
	
	$original_sidebar_type = original_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $original_sidebar_type && ! original_is_layouts_available() ) {
		$original_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $original_sidebar_type ) {
		// Default sidebar with widgets
		$original_sidebar_name = original_get_theme_option( 'sidebar_widgets' );
		original_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $original_sidebar_name ) ) {
			dynamic_sidebar( $original_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$original_sidebar_id = original_get_custom_sidebar_id();
		do_action( 'original_action_show_layout', $original_sidebar_id );
	}
	$original_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $original_out ) ) {
		$original_sidebar_position    = original_get_theme_option( 'sidebar_position' );
		$original_sidebar_position_ss = original_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $original_sidebar_position );
			echo ' sidebar_' . esc_attr( $original_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $original_sidebar_type );

			$original_sidebar_scheme = apply_filters( 'original_filter_sidebar_scheme', original_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $original_sidebar_scheme ) && ! original_is_inherit( $original_sidebar_scheme ) && 'custom' != $original_sidebar_type ) {
				echo ' scheme_' . esc_attr( $original_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<span id="sidebar_skip_link_anchor" class="original_skip_link_anchor"></span>
			<?php

			do_action( 'original_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $original_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$original_title = apply_filters( 'original_filter_sidebar_control_title', 'float' == $original_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'original' ) : '' );
				$original_text  = apply_filters( 'original_filter_sidebar_control_text', 'above' == $original_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'original' ) : '' );
				?>
				<a href="#" role="button" class="sidebar_control" title="<?php echo esc_attr( $original_title ); ?>"><?php echo esc_html( $original_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'original_action_before_sidebar', 'sidebar' );
				original_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $original_out ) );
				do_action( 'original_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'original_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
